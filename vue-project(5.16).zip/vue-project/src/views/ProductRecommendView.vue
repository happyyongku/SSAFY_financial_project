<template>
  <div>
    <h1>나에게 맞는 상품 추천</h1>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>