<template>
  <div>
    <h1>예적금 금리 비교</h1>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>